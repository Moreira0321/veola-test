# TODO

This file tracks tasks for the project.

## Features to Add

- [ ] Add a **GraphQL endpoint**  
       - Define schema for the endpoint  
       - Implement resolver to handle the request  
       - Connect it to existing Prisma/MongoDB setup

Feel free to contact me via email lucas@veola.fit
